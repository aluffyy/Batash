package com.example.batash_weatherapp

data class Clouds(
    val all: Int
)