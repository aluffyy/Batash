package com.example.batash_weatherapp

data class Wind(
    val deg: Int,
    val speed: Double
)