package com.example.batash_weatherapp

data class Coord(
    val lat: Double,
    val lon: Double
)